<?php
/**
 * Created by PhpStorm.
 * User: 低语
 * Date: 2016/7/8
 * Time: 10:15
 */
return array(
	//引入文件的绝对路径
	'CSS_URL' => 'http://www.chmake.cn/Public/Admin/css/',
	'JS_URL' => 'http://www.chmake.cn/Public/Admin/js/',
	'IMG_URL' => 'http://www.chmake.cn/Public/Admin/images/',
	'PLUGIN_URL' => 'http://www.chmake.cn/Common/Plugins/',


	'TMPL_LAYOUT_ITEM'      =>  '{__CONTENT__}', // 布局模板的内容替换标识
	'LAYOUT_ON'             =>  true, // 是否启用布局
	'LAYOUT_NAME'           =>  'layout', // 当前布局名称 默认为layout后缀是.html

);