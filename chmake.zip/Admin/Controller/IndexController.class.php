<?php

/**
 * Created by PhpStorm.
 * User: 低语
 * Date: 2016/7/8
 * Time: 10:09
 */
namespace Admin\Controller;

class IndexController extends CommonController
{
	public function index()
	{
		$this->display();
	}
}