<?php
/**
 * Created by PhpStorm.
 * User: 低语
 * Date: 2016/7/8
 * Time: 13:02
 */

namespace Admin\Controller;


class UserController extends CommonController
{
	public function login()
	{
		$this->display();
	}
}