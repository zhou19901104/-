<?php

/**
 * Created by PhpStorm.
 * User: 低语
 * Date: 2016/7/8
 * Time: 10:10
 */
namespace Admin\Controller;


use Think\Controller;

class CommonController extends Controller 
{
	public function __construct()
	{
		parent::__construct();
	}

}